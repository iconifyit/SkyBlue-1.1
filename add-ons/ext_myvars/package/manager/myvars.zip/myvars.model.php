<?php

defined('SKYBLUE') or die(basename(__FILE__));

class myvars_model {
    var $id           = null;
    var $name         = null;
    var $content      = null;
    var $cantarget    = 1;
    var $group        = 'collections';
    var $bundletype   = '';
    var $bundlesource = '';
    var $objtype      = null;
    var $loadas       = "";
}

?>